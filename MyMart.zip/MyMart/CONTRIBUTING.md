# Contributing to MyMart

## Local setup (clone to running instance)
1. `git clone <your-repo-url> && cd MyMart`
2. Install JDK 17 and Maven.
3. Copy config: `cp src/main/resources/config.properties.example src/main/resources/config.properties`
4. Start H2 in server mode (or let the app use embedded mode for local dev — default URL works out of the box).
5. Apply schema: `mvn -q exec:java -Dexec.mainClass=org.h2.tools.RunScript -Dexec.args="-url jdbc:h2:./data/mymart -script db/schema.sql"` (or just start the app once — `DataSourceListener` auto-applies `db/schema.sql` on first boot).
6. Load seed data similarly with `db/seed.sql`, or run `PasswordUtil` to generate real bcrypt hashes first.
7. Build: `mvn clean package`
8. Deploy `target/mymart.war` to Tomcat 9's `webapps/` folder, or run via `mvn tomcat7:run` if you add the plugin.
9. Visit `http://localhost:8080/mymart/`

## Branching
- `main` is always deployable.
- Work in `feature/<name>` branches, open a self-reviewed PR into `main`.
- Commit messages: `feat:`, `fix:`, `test:`, `docs:` (Conventional Commits).

## Before opening a PR
- `mvn -B clean verify` passes locally.
- Checkstyle/SpotBugs show no major warnings.
- Migration script included if you changed the schema (see `db/migrations/`).
- README/API docs updated if behavior changed.
