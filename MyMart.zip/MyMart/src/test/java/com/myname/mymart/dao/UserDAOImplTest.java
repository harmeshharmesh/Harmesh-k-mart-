package com.myname.mymart.dao;

import com.myname.mymart.model.User;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class UserDAOImplTest {

    private static final String JDBC_URL = "jdbc:h2:mem:test;DB_CLOSE_DELAY=-1";
    private Connection sharedConnection;
    private UserDAO userDAO;

    @BeforeEach
    void setUp() throws SQLException, IOException {
        sharedConnection = DriverManager.getConnection(JDBC_URL, "sa", "");
        try (Statement stmt = sharedConnection.createStatement()) {
            String schema = new String(Files.readAllBytes(Paths.get("db/schema.sql")));
            for (String s : schema.split(";")) {
                if (!s.trim().isEmpty()) stmt.execute(s);
            }
        }
        userDAO = new UserDAOImpl(() -> {
            try {
                // reuse the same in-memory DB; a new logical connection keeps DAO try-with-resources semantics
                return DriverManager.getConnection(JDBC_URL, "sa", "");
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        });
    }

    @AfterEach
    void tearDown() throws SQLException {
        try (Statement stmt = sharedConnection.createStatement()) {
            stmt.execute("DROP ALL OBJECTS");
        }
        sharedConnection.close();
    }

    @Test
    void createAndFindByEmail() throws SQLException {
        User user = new User();
        user.setName("Test User");
        user.setEmail("test@example.com");
        user.setPasswordHash("hashed");
        user.setRole("BUYER");

        User created = userDAO.create(user);
        assertTrue(created.getId() > 0);

        Optional<User> found = userDAO.findByEmail("test@example.com");
        assertTrue(found.isPresent());
        assertEquals("Test User", found.get().getName());
        assertEquals("BUYER", found.get().getRole());
    }

    @Test
    void findByEmail_returnsEmpty_whenNotFound() throws SQLException {
        assertTrue(userDAO.findByEmail("nobody@example.com").isEmpty());
    }

    @Test
    void emailUniqueConstraint_rejectsDuplicate() throws SQLException {
        User user = new User();
        user.setName("First");
        user.setEmail("dup@example.com");
        user.setPasswordHash("h");
        user.setRole("BUYER");
        userDAO.create(user);

        User dup = new User();
        dup.setName("Second");
        dup.setEmail("dup@example.com");
        dup.setPasswordHash("h2");
        dup.setRole("SELLER");

        assertThrows(SQLException.class, () -> userDAO.create(dup));
    }
}
