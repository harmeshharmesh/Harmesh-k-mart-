package com.myname.mymart.service;

import com.myname.mymart.dao.UserDAO;
import com.myname.mymart.model.User;
import com.myname.mymart.util.PasswordUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.sql.SQLException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserServiceTest {

    private UserDAO userDAO;
    private UserService userService;

    @BeforeEach
    void setUp() {
        userDAO = mock(UserDAO.class);
        userService = new UserService(userDAO);
    }

    @Test
    void register_rejectsShortPassword() {
        assertThrows(IllegalArgumentException.class,
                () -> userService.register("Name", "a@b.com", "short", "BUYER"));
    }

    @Test
    void register_rejectsInvalidRole() {
        assertThrows(IllegalArgumentException.class,
                () -> userService.register("Name", "a@b.com", "longenough1", "ADMIN"));
    }

    @Test
    void register_rejectsDuplicateEmail() throws SQLException {
        when(userDAO.findByEmail("a@b.com")).thenReturn(Optional.of(new User()));
        assertThrows(IllegalStateException.class,
                () -> userService.register("Name", "a@b.com", "longenough1", "BUYER"));
    }

    @Test
    void authenticate_returnsEmpty_onWrongPassword() throws SQLException {
        User stored = new User();
        stored.setPasswordHash(PasswordUtil.hash("correctPassword"));
        when(userDAO.findByEmail("a@b.com")).thenReturn(Optional.of(stored));

        assertTrue(userService.authenticate("a@b.com", "wrongPassword").isEmpty());
    }

    @Test
    void authenticate_succeeds_withCorrectPassword() throws SQLException {
        User stored = new User();
        stored.setPasswordHash(PasswordUtil.hash("correctPassword"));
        when(userDAO.findByEmail("a@b.com")).thenReturn(Optional.of(stored));

        assertTrue(userService.authenticate("a@b.com", "correctPassword").isPresent());
    }
}
