package com.myname.mymart.dao;

import com.myname.mymart.model.Product;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public interface ProductDAO {
    /** Decrements stock as part of an external transaction (used by checkout). Throws if insufficient stock. */
    void decrementStock(Connection conn, long productId, int quantity) throws SQLException;
    Product create(Product product) throws SQLException;
    boolean update(Product product) throws SQLException;
    boolean delete(long id, long sellerId) throws SQLException;
    Optional<Product> findById(long id) throws SQLException;
    List<Product> search(String keyword, String category) throws SQLException;
    List<Product> findBySeller(long sellerId) throws SQLException;
    List<Product> findAll() throws SQLException;
}
