package com.myname.mymart.controller;

import com.myname.mymart.listener.DataSourceListener;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/api/v1/health")
public class HealthServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String dbStatus = "DOWN";
        try (java.sql.Connection conn = DataSourceListener.getConnection()) {
            if (conn.isValid(2)) dbStatus = "UP";
        } catch (Exception ignored) {
        }
        resp.setContentType("application/json");
        resp.getWriter().write("{\"status\":\"UP\",\"db\":\"" + dbStatus + "\"}");
    }
}
