package com.myname.mymart.dao;

import java.sql.SQLException;
import java.util.List;

public interface ReviewDAO {
    void create(long productId, long userId, int rating, String comment) throws SQLException;
    List<java.util.Map<String, Object>> findByProduct(long productId) throws SQLException;
    double averageRating(long productId) throws SQLException;
    boolean buyerCompletedOrderFor(long userId, long productId) throws SQLException;
}
