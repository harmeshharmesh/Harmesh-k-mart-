package com.myname.mymart.listener;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.Statement;
import java.util.Properties;

/**
 * Single owner of the connection pool lifecycle, per architecture spec rule #5.
 * No DriverManager.getConnection() calls should exist outside this class.
 */
@WebListener
public class DataSourceListener implements ServletContextListener {

    private static final Logger log = LoggerFactory.getLogger(DataSourceListener.class);
    private static HikariDataSource dataSource;

    public static Connection getConnection() throws java.sql.SQLException {
        if (dataSource == null) {
            throw new IllegalStateException("DataSource not initialized yet");
        }
        return dataSource.getConnection();
    }

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        Properties props = loadConfig();

        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(props.getProperty("db.url", "jdbc:h2:./data/mymart;AUTO_SERVER=TRUE"));
        config.setUsername(props.getProperty("db.user", "sa"));
        config.setPassword(props.getProperty("db.password", ""));
        config.setDriverClassName("org.h2.Driver");
        config.setMaximumPoolSize(10);
        config.setMinimumIdle(2);
        dataSource = new HikariDataSource(config);

        log.info("HikariCP datasource initialized: {}", config.getJdbcUrl());
        runSchemaIfNeeded();
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        if (dataSource != null) {
            dataSource.close();
            log.info("HikariCP datasource closed");
        }
    }

    private Properties loadConfig() {
        Properties props = new Properties();
        try (InputStream in = getClass().getClassLoader().getResourceAsStream("config.properties")) {
            if (in != null) {
                props.load(in);
            } else {
                log.warn("config.properties not found on classpath; using defaults. " +
                        "Copy config.properties.example to config.properties.");
            }
        } catch (IOException e) {
            log.error("Failed to load config.properties", e);
        }
        return props;
    }

    /** Applies schema.sql on startup if the users table does not yet exist (idempotent, dev convenience). */
    private void runSchemaIfNeeded() {
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {
            String sql = new String(Files.readAllBytes(java.nio.file.Paths.get("db/schema.sql")));
            for (String statement : sql.split(";")) {
                if (!statement.trim().isEmpty()) {
                    stmt.execute(statement);
                }
            }
            log.info("Schema verified/applied on startup");
        } catch (Exception e) {
            log.warn("Could not auto-apply schema.sql (this is OK if already applied manually): {}", e.getMessage());
        }
    }
}
