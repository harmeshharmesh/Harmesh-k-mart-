package com.myname.mymart.controller;

import com.myname.mymart.dao.UserDAOImpl;
import com.myname.mymart.listener.DataSourceListener;
import com.myname.mymart.model.User;
import com.myname.mymart.service.UserService;
import com.myname.mymart.util.JsonUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/api/v1/register")
public class RegisterServlet extends HttpServlet {

    private UserService userService;

    @Override
    public void init() {
        userService = new UserService(new UserDAOImpl(this::getConnection));
    }

    private java.sql.Connection getConnection() {
        try {
            return DataSourceListener.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String role = req.getParameter("role");

        try {
            User user = userService.register(name, email, password, role);
            req.getSession(true).setAttribute("userId", user.getId());
            req.getSession().setAttribute("role", user.getRole());
            req.getSession().setAttribute("name", user.getName());
            JsonUtil.writeSuccess(resp, 201, java.util.Map.of(
                    "id", user.getId(), "name", user.getName(), "role", user.getRole()));
        } catch (IllegalArgumentException e) {
            JsonUtil.writeError(resp, 400, "VALIDATION_ERROR", e.getMessage());
        } catch (IllegalStateException e) {
            JsonUtil.writeError(resp, 409, "EMAIL_TAKEN", e.getMessage());
        } catch (SQLException e) {
            JsonUtil.writeError(resp, 500, "SERVER_ERROR", "Registration failed");
        }
    }
}
