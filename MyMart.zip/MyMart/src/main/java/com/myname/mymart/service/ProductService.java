package com.myname.mymart.service;

import com.myname.mymart.dao.ProductDAO;
import com.myname.mymart.model.Product;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class ProductService {

    private final ProductDAO productDAO;

    public ProductService(ProductDAO productDAO) {
        this.productDAO = productDAO;
    }

    public Product createListing(long sellerId, String name, String description, BigDecimal price,
                                  int stockQty, String category, String imageUrl) throws SQLException {
        validate(name, price, stockQty);
        Product p = new Product();
        p.setSellerId(sellerId);
        p.setName(name);
        p.setDescription(description);
        p.setPrice(price);
        p.setStockQty(stockQty);
        p.setCategory(category);
        p.setImageUrl(imageUrl);
        return productDAO.create(p);
    }

    public boolean updateListing(Product p) throws SQLException {
        validate(p.getName(), p.getPrice(), p.getStockQty());
        return productDAO.update(p);
    }

    public boolean deleteListing(long id, long sellerId) throws SQLException {
        return productDAO.delete(id, sellerId);
    }

    public Optional<Product> get(long id) throws SQLException {
        return productDAO.findById(id);
    }

    public List<Product> search(String keyword, String category) throws SQLException {
        return productDAO.search(keyword, category);
    }

    public List<Product> forSeller(long sellerId) throws SQLException {
        return productDAO.findBySeller(sellerId);
    }

    public List<Product> all() throws SQLException {
        return productDAO.findAll();
    }

    private void validate(String name, BigDecimal price, int stockQty) {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Product name is required");
        if (price == null || price.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Price must be greater than zero");
        }
        if (stockQty < 0) throw new IllegalArgumentException("Stock quantity cannot be negative");
    }
}
