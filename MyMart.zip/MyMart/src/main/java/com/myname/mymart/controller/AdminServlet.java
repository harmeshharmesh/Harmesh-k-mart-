package com.myname.mymart.controller;

import com.myname.mymart.dao.OrderDAOImpl;
import com.myname.mymart.dao.ProductDAOImpl;
import com.myname.mymart.dao.UserDAOImpl;
import com.myname.mymart.listener.DataSourceListener;
import com.myname.mymart.model.User;
import com.myname.mymart.service.OrderService;
import com.myname.mymart.service.ProductService;
import com.myname.mymart.dao.CartDAOImpl;
import com.myname.mymart.util.JsonUtil;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Registered under /admin/* so AuthFilter enforces both login AND role=ADMIN (F7).
 * GET  /admin/users               -> all users (password hashes stripped)
 * GET  /admin/orders              -> all orders
 * POST /admin/products?action=remove&id=  -> moderate/remove a listing
 */
@WebServlet({"/admin/users", "/admin/orders", "/admin/products"})
public class AdminServlet extends HttpServlet {

    private com.myname.mymart.dao.UserDAOImpl userDAO;
    private OrderService orderService;
    private ProductService productService;

    @Override
    public void init() {
        java.util.function.Supplier<java.sql.Connection> supplier = this::getConnection;
        userDAO = new UserDAOImpl(supplier);
        orderService = new OrderService(new OrderDAOImpl(supplier), new CartDAOImpl(supplier),
                new ProductDAOImpl(supplier), supplier);
        productService = new ProductService(new ProductDAOImpl(supplier));
    }

    private java.sql.Connection getConnection() {
        try {
            return DataSourceListener.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String path = req.getServletPath();
        try {
            if (path.endsWith("/users")) {
                List<User> users = userDAO.findAll();
                // DTO: never expose passwordHash (Section 13 rule #4)
                List<Map<String, Object>> safe = users.stream().map(u -> Map.<String, Object>of(
                        "id", u.getId(), "name", u.getName(), "email", u.getEmail(),
                        "role", u.getRole(), "createdAt", String.valueOf(u.getCreatedAt())
                )).collect(Collectors.toList());
                JsonUtil.writeSuccess(resp, 200, safe);
            } else if (path.endsWith("/orders")) {
                JsonUtil.writeSuccess(resp, 200, orderService.allOrders());
            }
        } catch (SQLException e) {
            JsonUtil.writeError(resp, 500, "SERVER_ERROR", "Admin query failed");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String action = req.getParameter("action");
        try {
            if ("remove".equals(action)) {
                long id = Long.parseLong(req.getParameter("id"));
                // admin override: bypasses the seller-ownership check DAO-level via direct delete
                boolean removed = productService.get(id).isPresent()
                        && productService.deleteListing(id, productService.get(id).get().getSellerId());
                if (removed) JsonUtil.writeSuccess(resp, 200, Map.of("removed", true));
                else JsonUtil.writeError(resp, 404, "NOT_FOUND", "Listing not found");
            } else {
                JsonUtil.writeError(resp, 400, "VALIDATION_ERROR", "Unknown action");
            }
        } catch (SQLException e) {
            JsonUtil.writeError(resp, 500, "SERVER_ERROR", "Moderation action failed");
        }
    }
}
