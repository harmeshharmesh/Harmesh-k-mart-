package com.myname.mymart.service;

import com.myname.mymart.dao.CartDAO;
import com.myname.mymart.model.CartItem;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

public class CartService {

    private final CartDAO cartDAO;

    public CartService(CartDAO cartDAO) {
        this.cartDAO = cartDAO;
    }

    public void addItem(long userId, long productId, int quantity) throws SQLException {
        if (quantity <= 0) throw new IllegalArgumentException("Quantity must be positive");
        cartDAO.addOrIncrement(userId, productId, quantity);
    }

    public void updateItem(long userId, long productId, int quantity) throws SQLException {
        if (quantity <= 0) {
            cartDAO.remove(userId, productId);
        } else {
            cartDAO.updateQuantity(userId, productId, quantity);
        }
    }

    public void removeItem(long userId, long productId) throws SQLException {
        cartDAO.remove(userId, productId);
    }

    public List<CartItem> getCart(long userId) throws SQLException {
        return cartDAO.findByUser(userId);
    }

    public BigDecimal getRunningTotal(long userId) throws SQLException {
        return cartDAO.findByUser(userId).stream()
                .map(CartItem::getLineTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public void clearCart(long userId) throws SQLException {
        cartDAO.clear(userId);
    }
}
