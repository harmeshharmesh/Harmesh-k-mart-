package com.myname.mymart.service;

import com.myname.mymart.dao.UserDAO;
import com.myname.mymart.model.User;
import com.myname.mymart.util.PasswordUtil;

import java.sql.SQLException;
import java.util.Optional;
import java.util.Set;

public class UserService {

    private static final Set<String> VALID_ROLES = Set.of("BUYER", "SELLER");

    private final UserDAO userDAO;

    public UserService(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    public User register(String name, String email, String plainPassword, String role) throws SQLException {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Name is required");
        if (email == null || !email.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) {
            throw new IllegalArgumentException("Valid email is required");
        }
        if (plainPassword == null || plainPassword.length() < 8) {
            throw new IllegalArgumentException("Password must be at least 8 characters");
        }
        if (!VALID_ROLES.contains(role)) {
            throw new IllegalArgumentException("Role must be BUYER or SELLER");
        }
        if (userDAO.findByEmail(email).isPresent()) {
            throw new IllegalStateException("Email already registered");
        }

        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPasswordHash(PasswordUtil.hash(plainPassword));
        user.setRole(role);
        return userDAO.create(user);
    }

    /** Returns the user if credentials are valid, empty otherwise. Never reveals which field was wrong. */
    public Optional<User> authenticate(String email, String plainPassword) throws SQLException {
        Optional<User> userOpt = userDAO.findByEmail(email);
        if (userOpt.isEmpty()) return Optional.empty();
        User user = userOpt.get();
        if (!PasswordUtil.verify(plainPassword, user.getPasswordHash())) return Optional.empty();
        return Optional.of(user);
    }
}
