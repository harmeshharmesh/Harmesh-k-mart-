package com.myname.mymart.service;

import com.myname.mymart.dao.ReviewDAO;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class ReviewService {

    private final ReviewDAO reviewDAO;

    public ReviewService(ReviewDAO reviewDAO) {
        this.reviewDAO = reviewDAO;
    }

    public void submitReview(long userId, long productId, int rating, String comment) throws SQLException {
        if (rating < 1 || rating > 5) throw new IllegalArgumentException("Rating must be between 1 and 5");
        if (!reviewDAO.buyerCompletedOrderFor(userId, productId)) {
            throw new IllegalStateException("You can only review products from delivered orders");
        }
        reviewDAO.create(productId, userId, rating, comment);
    }

    public List<Map<String, Object>> getReviews(long productId) throws SQLException {
        return reviewDAO.findByProduct(productId);
    }

    public double getAverageRating(long productId) throws SQLException {
        return reviewDAO.averageRating(productId);
    }
}
