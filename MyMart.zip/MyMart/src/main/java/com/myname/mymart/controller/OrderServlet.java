package com.myname.mymart.controller;

import com.myname.mymart.dao.CartDAOImpl;
import com.myname.mymart.dao.OrderDAOImpl;
import com.myname.mymart.dao.ProductDAOImpl;
import com.myname.mymart.listener.DataSourceListener;
import com.myname.mymart.model.Order;
import com.myname.mymart.service.OrderService;
import com.myname.mymart.util.JsonUtil;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * Registered under /order/* so AuthFilter enforces login.
 * POST /order/checkout        -> place order from cart via mock payment (F5)
 * GET  /order/history         -> buyer's past orders, or seller's incoming orders (F6)
 */
@WebServlet({"/order/checkout", "/order/history"})
public class OrderServlet extends HttpServlet {

    private OrderService orderService;

    @Override
    public void init() {
        java.util.function.Supplier<java.sql.Connection> supplier = this::getConnection;
        orderService = new OrderService(
                new OrderDAOImpl(supplier),
                new CartDAOImpl(supplier),
                new ProductDAOImpl(supplier),
                supplier);
    }

    private java.sql.Connection getConnection() {
        try {
            return DataSourceListener.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession(false);
        long buyerId = (long) session.getAttribute("userId");
        // Mock payment confirmation step (F5) — real gateway integration is out of scope.
        boolean mockPaymentConfirmed = "true".equals(req.getParameter("confirmPayment"));

        try {
            Order order = orderService.checkout(buyerId, mockPaymentConfirmed);
            JsonUtil.writeSuccess(resp, 201, order);
        } catch (IllegalStateException e) {
            JsonUtil.writeError(resp, 400, "CHECKOUT_ERROR", e.getMessage());
        } catch (SQLException e) {
            JsonUtil.writeError(resp, 500, "SERVER_ERROR", "Checkout failed");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession(false);
        long userId = (long) session.getAttribute("userId");
        String role = (String) session.getAttribute("role");

        try {
            List<Order> orders = "SELLER".equals(role)
                    ? orderService.sellerIncomingOrders(userId)
                    : orderService.buyerHistory(userId);
            JsonUtil.writeSuccess(resp, 200, orders);
        } catch (SQLException e) {
            JsonUtil.writeError(resp, 500, "SERVER_ERROR", "Could not load orders");
        }
    }
}
