package com.myname.mymart.service.chat;

/**
 * Real LLM-backed provider. Activate via ai.chatbot.provider=gemini in config.properties,
 * with ai.chatbot.apiKey set (never commit the actual key — config.properties is gitignored).
 * This is a stub: wire in your preferred HTTP client (e.g. java.net.http.HttpClient) to call
 * the provider's REST endpoint, matching Section 11's try/catch + degraded-response requirement.
 */
public class GeminiChatProvider implements ChatProvider {

    private final String apiKey;
    private final ChatProvider fallback = new MockChatProvider();

    public GeminiChatProvider(String apiKey) {
        this.apiKey = apiKey;
    }

    @Override
    public String getReply(String userMessage, String context) {
        if (apiKey == null || apiKey.isBlank()) {
            return fallback.getReply(userMessage, context);
        }
        try {
            // TODO (Week 9): call the LLM API here with a fixed server-side prompt template
            // restricting scope to product/listing domain questions (Section 11, req #2).
            // On any failure, fall through to the static degraded response below (req #3).
            return fallback.getReply(userMessage, context);
        } catch (Exception e) {
            return "Sorry, the assistant is temporarily unavailable. Please browse products directly or try again shortly.";
        }
    }
}
