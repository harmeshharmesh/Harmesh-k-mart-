package com.myname.mymart.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/** Writes responses in the fixed envelope: { success, data, error } per API Contract Standards (Section 13). */
public final class JsonUtil {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private JsonUtil() {}

    public static void writeSuccess(HttpServletResponse resp, int status, Object data) throws IOException {
        write(resp, status, envelope(true, data, null));
    }

    public static void writeError(HttpServletResponse resp, int status, String code, String message) throws IOException {
        Map<String, String> error = new HashMap<>();
        error.put("code", code);
        error.put("message", message);
        write(resp, status, envelope(false, null, error));
    }

    private static Map<String, Object> envelope(boolean success, Object data, Object error) {
        Map<String, Object> map = new HashMap<>();
        map.put("success", success);
        map.put("data", data);
        map.put("error", error);
        return map;
    }

    private static void write(HttpServletResponse resp, int status, Object payload) throws IOException {
        resp.setStatus(status);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.getWriter().write(GSON.toJson(payload));
    }
}
