package com.myname.mymart.dao;

import com.myname.mymart.model.Order;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public interface OrderDAO {
    /** Persists an order and its items in a single transaction using the given connection. */
    Order createWithItems(Connection conn, Order order) throws SQLException;
    List<Order> findByBuyer(long buyerId) throws SQLException;
    List<Order> findBySellerProducts(long sellerId) throws SQLException;
    Optional<Order> findById(long orderId) throws SQLException;
    List<Order> findAll() throws SQLException;
    boolean updateStatus(long orderId, String status) throws SQLException;
}
