package com.myname.mymart.controller;

import com.myname.mymart.dao.CartDAOImpl;
import com.myname.mymart.listener.DataSourceListener;
import com.myname.mymart.service.CartService;
import com.myname.mymart.util.JsonUtil;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

/**
 * Registered under /cart/* so AuthFilter enforces login.
 * GET  /cart/api            -> current cart + running total (F4)
 * POST /cart/api            -> add item
 * POST /cart/api?action=update -> change quantity
 * POST /cart/api?action=remove -> remove item
 */
@WebServlet("/cart/api")
public class CartServlet extends HttpServlet {

    private CartService cartService;

    @Override
    public void init() {
        cartService = new CartService(new CartDAOImpl(this::getConnection));
    }

    private java.sql.Connection getConnection() {
        try {
            return DataSourceListener.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private long currentUserId(HttpServletRequest req) {
        HttpSession session = req.getSession(false);
        return (long) session.getAttribute("userId");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        try {
            long userId = currentUserId(req);
            JsonUtil.writeSuccess(resp, 200, Map.of(
                    "items", cartService.getCart(userId),
                    "total", cartService.getRunningTotal(userId)));
        } catch (SQLException e) {
            JsonUtil.writeError(resp, 500, "SERVER_ERROR", "Could not load cart");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        long userId = currentUserId(req);
        String action = req.getParameter("action");
        try {
            long productId = Long.parseLong(req.getParameter("productId"));
            if ("remove".equals(action)) {
                cartService.removeItem(userId, productId);
            } else if ("update".equals(action)) {
                int qty = Integer.parseInt(req.getParameter("quantity"));
                cartService.updateItem(userId, productId, qty);
            } else {
                int qty = Integer.parseInt(req.getParameter("quantity"));
                cartService.addItem(userId, productId, qty);
            }
            JsonUtil.writeSuccess(resp, 200, Map.of(
                    "items", cartService.getCart(userId),
                    "total", cartService.getRunningTotal(userId)));
        } catch (IllegalArgumentException e) {
            JsonUtil.writeError(resp, 400, "VALIDATION_ERROR", e.getMessage());
        } catch (SQLException e) {
            JsonUtil.writeError(resp, 500, "SERVER_ERROR", "Cart update failed");
        }
    }
}
