package com.myname.mymart.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Set;

/**
 * Blocks access to protected endpoints unless a valid session with a "userId" attribute exists.
 * Registered for /cart/*, /order/*, /seller/*, /admin/* — see web.xml.
 */
@WebFilter(urlPatterns = {"/cart/*", "/order/*", "/seller/*", "/admin/*"})
public class AuthFilter implements Filter {

    private static final Set<String> PUBLIC_SUFFIXES = Set.of("/login", "/register");

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;

        String path = request.getRequestURI();
        boolean isPublic = PUBLIC_SUFFIXES.stream().anyMatch(path::endsWith);

        HttpSession session = request.getSession(false);
        boolean authenticated = session != null && session.getAttribute("userId") != null;

        if (isPublic || authenticated) {
            if (path.contains("/admin/") && authenticated) {
                String role = (String) session.getAttribute("role");
                if (!"ADMIN".equals(role)) {
                    response.sendError(HttpServletResponse.SC_FORBIDDEN, "Admin access required");
                    return;
                }
            }
            if (path.contains("/seller/") && authenticated) {
                String role = (String) session.getAttribute("role");
                if (!"SELLER".equals(role)) {
                    response.sendError(HttpServletResponse.SC_FORBIDDEN, "Seller access required");
                    return;
                }
            }
            chain.doFilter(req, res);
        } else {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Login required");
        }
    }
}
