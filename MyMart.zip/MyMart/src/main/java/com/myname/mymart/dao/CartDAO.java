package com.myname.mymart.dao;

import com.myname.mymart.model.CartItem;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public interface CartDAO {
    void addOrIncrement(long userId, long productId, int quantity) throws SQLException;
    void updateQuantity(long userId, long productId, int quantity) throws SQLException;
    void remove(long userId, long productId) throws SQLException;
    void clear(long userId) throws SQLException;
    /** Clears the cart as part of an external transaction (used by checkout). */
    void clear(Connection conn, long userId) throws SQLException;
    List<CartItem> findByUser(long userId) throws SQLException;
    Optional<CartItem> find(long userId, long productId) throws SQLException;
}
