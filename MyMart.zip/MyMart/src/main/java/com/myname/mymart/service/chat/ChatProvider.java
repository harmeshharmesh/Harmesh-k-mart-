package com.myname.mymart.service.chat;

public interface ChatProvider {
    String getReply(String userMessage, String context);
}
