package com.myname.mymart.service.chat;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Default provider (ai.chatbot.provider=mock). Canned FAQ answers so the chatbot UI
 * works out of the box without an API key. Swap to a real provider (e.g. GeminiChatProvider,
 * implemented the same way, calling an LLM API server-side) once you have credentials.
 */
public class MockChatProvider implements ChatProvider {

    private static final Map<String, String> FAQ = new LinkedHashMap<>();
    static {
        FAQ.put("shipping", "Orders are marked Confirmed after mock payment, then move to Shipped and Delivered as the seller updates status.");
        FAQ.put("return", "Returns aren't part of this project's scope yet — check with the seller directly via order details.");
        FAQ.put("payment", "Checkout uses a mock payment confirmation step — no real card or bank details are processed.");
        FAQ.put("review", "You can leave a star rating and review once an order is marked Delivered.");
        FAQ.put("seller", "Sellers can list, edit, and delete products from their seller dashboard.");
        FAQ.put("cart", "Add items from the product listing page; quantities and totals update live in your cart.");
        FAQ.put("account", "Register as a Buyer or Seller from the Register page; Admin accounts are seeded, not self-signed-up.");
    }

    @Override
    public String getReply(String userMessage, String context) {
        String lower = userMessage == null ? "" : userMessage.toLowerCase();
        for (Map.Entry<String, String> entry : FAQ.entrySet()) {
            if (lower.contains(entry.getKey())) {
                return entry.getValue();
            }
        }
        return "I can help with questions about shipping, payment, returns, reviews, cart, or your account. Could you rephrase your question?";
    }
}
