package com.myname.mymart.service;

import com.myname.mymart.dao.CartDAO;
import com.myname.mymart.dao.OrderDAO;
import com.myname.mymart.dao.ProductDAO;
import com.myname.mymart.model.CartItem;
import com.myname.mymart.model.Order;
import com.myname.mymart.model.OrderItem;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * Owns the checkout transaction: place order from cart -> decrement stock -> clear cart,
 * all committed or rolled back together. Mirrors the sequence diagram (Section 5, D3):
 * Servlet -> Service -> DAO -> Database -> response.
 */
public class OrderService {

    private final OrderDAO orderDAO;
    private final CartDAO cartDAO;
    private final ProductDAO productDAO;
    private final Supplier<Connection> connectionSupplier;

    public OrderService(OrderDAO orderDAO, CartDAO cartDAO, ProductDAO productDAO,
                         Supplier<Connection> connectionSupplier) {
        this.orderDAO = orderDAO;
        this.cartDAO = cartDAO;
        this.productDAO = productDAO;
        this.connectionSupplier = connectionSupplier;
    }

    /** Places an order from the buyer's current cart via mock payment confirmation (F5). */
    public Order checkout(long buyerId, boolean mockPaymentConfirmed) throws SQLException {
        if (!mockPaymentConfirmed) {
            throw new IllegalStateException("Payment was not confirmed");
        }

        List<CartItem> cartItems = cartDAO.findByUser(buyerId);
        if (cartItems.isEmpty()) {
            throw new IllegalStateException("Cart is empty");
        }

        Order order = new Order();
        order.setBuyerId(buyerId);
        order.setStatus("CONFIRMED"); // mock payment confirmed immediately
        BigDecimal total = BigDecimal.ZERO;
        for (CartItem ci : cartItems) {
            OrderItem oi = new OrderItem();
            oi.setProductId(ci.getProductId());
            oi.setQuantity(ci.getQuantity());
            oi.setUnitPrice(ci.getUnitPrice());
            order.getItems().add(oi);
            total = total.add(ci.getLineTotal());
        }
        order.setTotalAmount(total);

        try (Connection conn = connectionSupplier.get()) {
            conn.setAutoCommit(false);
            try {
                Order saved = orderDAO.createWithItems(conn, order);
                for (CartItem ci : cartItems) {
                    productDAO.decrementStock(conn, ci.getProductId(), ci.getQuantity());
                }
                cartDAO.clear(conn, buyerId);
                conn.commit();
                return saved;
            } catch (SQLException | RuntimeException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        }
    }

    public List<Order> buyerHistory(long buyerId) throws SQLException {
        return orderDAO.findByBuyer(buyerId);
    }

    public List<Order> sellerIncomingOrders(long sellerId) throws SQLException {
        return orderDAO.findBySellerProducts(sellerId);
    }

    public List<Order> allOrders() throws SQLException {
        return orderDAO.findAll();
    }

    public Optional<Order> get(long orderId) throws SQLException {
        return orderDAO.findById(orderId);
    }

    public boolean updateStatus(long orderId, String status) throws SQLException {
        return orderDAO.updateStatus(orderId, status);
    }
}
