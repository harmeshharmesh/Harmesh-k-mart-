package com.myname.mymart.util;

import org.mindrot.jbcrypt.BCrypt;

public final class PasswordUtil {

    private PasswordUtil() {}

    public static String hash(String plainPassword) {
        return BCrypt.hashpw(plainPassword, BCrypt.gensalt(10));
    }

    public static boolean verify(String plainPassword, String hash) {
        return BCrypt.checkpw(plainPassword, hash);
    }

    /** Run with `mvn exec:java -Dexec.mainClass=...PasswordUtil -Dexec.args="yourPassword"`
     *  to generate a real bcrypt hash for seed.sql. */
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Usage: PasswordUtil <plainPassword>");
            return;
        }
        System.out.println(hash(args[0]));
    }
}
