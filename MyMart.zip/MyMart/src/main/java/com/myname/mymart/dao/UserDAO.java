package com.myname.mymart.dao;

import com.myname.mymart.model.User;
import java.sql.SQLException;
import java.util.Optional;

public interface UserDAO {
    User create(User user) throws SQLException;
    Optional<User> findByEmail(String email) throws SQLException;
    Optional<User> findById(long id) throws SQLException;
    java.util.List<User> findAll() throws SQLException;
}
