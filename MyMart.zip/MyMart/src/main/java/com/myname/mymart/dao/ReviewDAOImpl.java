package com.myname.mymart.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public class ReviewDAOImpl implements ReviewDAO {

    private final Supplier<Connection> connectionSupplier;

    public ReviewDAOImpl(Supplier<Connection> connectionSupplier) {
        this.connectionSupplier = connectionSupplier;
    }

    @Override
    public void create(long productId, long userId, int rating, String comment) throws SQLException {
        String sql = "INSERT INTO reviews (product_id, user_id, rating, comment) VALUES (?, ?, ?, ?)";
        try (Connection conn = connectionSupplier.get();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, productId);
            ps.setLong(2, userId);
            ps.setInt(3, rating);
            ps.setString(4, comment);
            ps.executeUpdate();
        }
    }

    @Override
    public List<Map<String, Object>> findByProduct(long productId) throws SQLException {
        String sql = "SELECT r.rating, r.comment, r.created_at, u.name AS reviewer " +
                "FROM reviews r JOIN users u ON r.user_id = u.id WHERE r.product_id = ? ORDER BY r.created_at DESC";
        try (Connection conn = connectionSupplier.get();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, productId);
            try (ResultSet rs = ps.executeQuery()) {
                List<Map<String, Object>> reviews = new ArrayList<>();
                while (rs.next()) {
                    Map<String, Object> row = new LinkedHashMap<>();
                    row.put("rating", rs.getInt("rating"));
                    row.put("comment", rs.getString("comment"));
                    row.put("reviewer", rs.getString("reviewer"));
                    row.put("createdAt", rs.getTimestamp("created_at"));
                    reviews.add(row);
                }
                return reviews;
            }
        }
    }

    @Override
    public double averageRating(long productId) throws SQLException {
        String sql = "SELECT AVG(rating) AS avg_rating FROM reviews WHERE product_id = ?";
        try (Connection conn = connectionSupplier.get();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, productId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getDouble("avg_rating") : 0.0;
            }
        }
    }

    /** F8 requires reviews only on completed orders — verify the buyer actually bought this product
     *  in a DELIVERED order before allowing a review. */
    @Override
    public boolean buyerCompletedOrderFor(long userId, long productId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM orders o JOIN order_items oi ON o.id = oi.order_id " +
                "WHERE o.buyer_id = ? AND oi.product_id = ? AND o.status = 'DELIVERED'";
        try (Connection conn = connectionSupplier.get();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            ps.setLong(2, productId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }
}
