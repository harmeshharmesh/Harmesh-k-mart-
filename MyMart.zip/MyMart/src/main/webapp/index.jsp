<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>MyMart</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header>
    <h1>MyMart</h1>
    <nav>
        <a href="${pageContext.request.contextPath}/index.jsp">Home</a>
        <a href="${pageContext.request.contextPath}/WEB-INF/jsp/products.jsp">Browse</a>
        <a href="${pageContext.request.contextPath}/WEB-INF/jsp/login.jsp">Login</a>
        <a href="${pageContext.request.contextPath}/WEB-INF/jsp/register.jsp">Register</a>
    </nav>
</header>
<main>
    <h2>Welcome to MyMart</h2>
    <p>A multi-seller marketplace built with Java Servlets, JDBC, and Tomcat.</p>
    <p>Product listing and browsing is wired to <code>/api/v1/products</code> — see
       <code>WEB-INF/jsp/products.jsp</code> for a working example using fetch().</p>
</main>
</body>
</html>
