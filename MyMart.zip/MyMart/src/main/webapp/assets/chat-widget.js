// Floating chat widget — include this script on any page: <script src="assets/chat-widget.js"></script>
(function () {
  const button = document.createElement('button');
  button.textContent = '💬';
  button.style.cssText = 'position:fixed;bottom:20px;right:20px;border-radius:50%;width:48px;height:48px;';
  const panel = document.createElement('div');
  panel.style.cssText = 'position:fixed;bottom:80px;right:20px;width:280px;max-height:360px;' +
      'overflow-y:auto;border:1px solid #ccc;background:#fff;display:none;padding:0.5rem;';
  const log = document.createElement('div');
  const inputRow = document.createElement('div');
  const input = document.createElement('input');
  input.placeholder = 'Ask about products, orders...';
  input.style.width = '80%';
  const send = document.createElement('button');
  send.textContent = 'Send';
  inputRow.appendChild(input);
  inputRow.appendChild(send);
  panel.appendChild(log);
  panel.appendChild(inputRow);
  document.body.appendChild(button);
  document.body.appendChild(panel);

  button.addEventListener('click', () => {
    panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
  });

  async function sendMessage() {
    const message = input.value.trim();
    if (!message) return;
    const you = document.createElement('div');
    you.textContent = 'You: ' + message;
    log.appendChild(you);
    input.value = '';

    const basePath = document.querySelector('meta[name="context-path"]');
    const contextPath = basePath ? basePath.content : '';
    const res = await fetch(contextPath + '/api/v1/chat', {
      method: 'POST',
      body: new URLSearchParams({ message })
    });
    const body = await res.json();
    const bot = document.createElement('div');
    bot.textContent = 'Bot: ' + (body.success ? body.data.reply : (body.error && body.error.message));
    log.appendChild(bot);
    log.scrollTop = log.scrollHeight;
  }

  send.addEventListener('click', sendMessage);
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') sendMessage(); });
})();
