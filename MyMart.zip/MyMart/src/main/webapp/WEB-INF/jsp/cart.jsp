<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Cart — MyMart</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css"></head>
<body>
<main>
  <h2>Your Cart</h2>
  <ul id="cartList"></ul>
  <p>Total: ₹<span id="total">0.00</span></p>
  <button id="checkoutBtn">Checkout (mock payment)</button>
  <p id="message"></p>
</main>
<script>
async function loadCart() {
  const res = await fetch('${pageContext.request.contextPath}/cart/api');
  const body = await res.json();
  const list = document.getElementById('cartList');
  list.innerHTML = '';
  if (!body.success) { document.getElementById('message').textContent = 'Please log in first.'; return; }
  body.data.items.forEach(function (item) {
    const li = document.createElement('li');
    li.textContent = item.productName + ' x ' + item.quantity + ' = ₹' + item.lineTotal;
    list.appendChild(li);
  });
  document.getElementById('total').textContent = body.data.total;
}
document.getElementById('checkoutBtn').addEventListener('click', async function () {
  const res = await fetch('${pageContext.request.contextPath}/order/checkout', {
    method: 'POST',
    body: new URLSearchParams({ confirmPayment: 'true' })
  });
  const body = await res.json();
  document.getElementById('message').textContent = body.success
    ? 'Order #' + body.data.id + ' placed!'
    : (body.error && body.error.message || 'Checkout failed');
  loadCart();
});
loadCart();
</script>
</body>
</html>
