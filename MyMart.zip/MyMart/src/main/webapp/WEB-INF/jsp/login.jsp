<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Login — MyMart</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css"></head>
<body>
<main>
  <h2>Login</h2>
  <form id="loginForm">
    <label>Email <input type="email" name="email" required></label>
    <label>Password <input type="password" name="password" required></label>
    <button type="submit">Login</button>
  </form>
  <p id="message"></p>
</main>
<script>
document.getElementById('loginForm').addEventListener('submit', async function (e) {
  e.preventDefault();
  const form = new URLSearchParams(new FormData(e.target));
  const res = await fetch('${pageContext.request.contextPath}/api/v1/login', { method: 'POST', body: form });
  const body = await res.json();
  document.getElementById('message').textContent = body.success
    ? 'Logged in as ' + body.data.name + ' (' + body.data.role + ')'
    : (body.error && body.error.message || 'Login failed');
});
</script>
</body>
</html>
