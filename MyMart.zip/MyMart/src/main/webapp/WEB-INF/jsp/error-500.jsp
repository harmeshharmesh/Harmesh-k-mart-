<%@ page contentType="text/html;charset=UTF-8" isErrorPage="true" %>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Server Error — MyMart</title></head>
<body><h2>Something went wrong</h2><p>Please try again later. The error has been logged.</p>
<a href="${pageContext.request.contextPath}/index.jsp">Return home</a></body></html>
