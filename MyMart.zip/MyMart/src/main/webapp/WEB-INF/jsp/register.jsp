<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Register — MyMart</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css"></head>
<body>
<main>
  <h2>Register</h2>
  <form id="registerForm">
    <label>Name <input type="text" name="name" required></label>
    <label>Email <input type="email" name="email" required></label>
    <label>Password <input type="password" name="password" minlength="8" required></label>
    <label>Role
      <select name="role">
        <option value="BUYER">Buyer</option>
        <option value="SELLER">Seller</option>
      </select>
    </label>
    <button type="submit">Create account</button>
  </form>
  <p id="message"></p>
</main>
<script>
document.getElementById('registerForm').addEventListener('submit', async function (e) {
  e.preventDefault();
  const form = new URLSearchParams(new FormData(e.target));
  const res = await fetch('${pageContext.request.contextPath}/api/v1/register', { method: 'POST', body: form });
  const body = await res.json();
  document.getElementById('message').textContent = body.success
    ? 'Account created for ' + body.data.name
    : (body.error && body.error.message || 'Registration failed');
});
</script>
</body>
</html>
