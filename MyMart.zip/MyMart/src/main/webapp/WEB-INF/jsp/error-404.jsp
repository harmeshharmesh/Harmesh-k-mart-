<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Not Found — MyMart</title></head>
<body><h2>404 — Page Not Found</h2><p>The page you requested does not exist.</p>
<a href="${pageContext.request.contextPath}/index.jsp">Return home</a></body></html>
