<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Browse — MyMart</title>
<link rel="stylesheet" href="${pageContext.request.contextPath}/assets/style.css"></head>
<body>
<main>
  <h2>Browse Products</h2>
  <form id="searchForm">
    <input type="text" name="q" placeholder="Search by name">
    <input type="text" name="category" placeholder="Category">
    <button type="submit">Search</button>
  </form>
  <ul id="productList"></ul>
</main>
<script>
async function loadProducts(params) {
  const qs = new URLSearchParams(params || {});
  const res = await fetch('${pageContext.request.contextPath}/api/v1/products?' + qs.toString());
  const body = await res.json();
  const list = document.getElementById('productList');
  list.innerHTML = '';
  if (!body.success) return;
  body.data.forEach(function (p) {
    const li = document.createElement('li');
    // textContent, not innerHTML: prevents XSS from user-supplied listing data
    const title = document.createElement('strong');
    title.textContent = p.name + ' — ₹' + p.price;
    const desc = document.createElement('div');
    desc.textContent = p.description || '';
    li.appendChild(title);
    li.appendChild(desc);
    list.appendChild(li);
  });
}
document.getElementById('searchForm').addEventListener('submit', function (e) {
  e.preventDefault();
  loadProducts(Object.fromEntries(new FormData(e.target)));
});
loadProducts();
</script>
</body>
</html>
