-- Seed data for MyMart
-- Admin password below is bcrypt hash for "AdminPass123!" — change before real deployment.
INSERT INTO users (name, email, password_hash, role) VALUES
  ('Site Admin', 'admin@mymart.local', '$2a$10$7EqJtq98hPqEX7fNZaFWoOa1V2y5T2s7v1r1Q9m5c5x8k5f5f5f5e', 'ADMIN');

INSERT INTO users (name, email, password_hash, role) VALUES
  ('Demo Seller', 'seller@mymart.local', '$2a$10$7EqJtq98hPqEX7fNZaFWoOa1V2y5T2s7v1r1Q9m5c5x8k5f5f5f5e', 'SELLER'),
  ('Demo Buyer', 'buyer@mymart.local', '$2a$10$7EqJtq98hPqEX7fNZaFWoOa1V2y5T2s7v1r1Q9m5c5x8k5f5f5f5e', 'BUYER');

INSERT INTO products (seller_id, name, description, price, stock_qty, category, image_url) VALUES
  (2, 'Acoustic Guitar', 'Steel-string acoustic guitar, beginner friendly', 4999.00, 10, 'Instruments', 'https://example.com/guitar.jpg'),
  (2, 'Wireless Mouse', 'Ergonomic 2.4GHz wireless mouse', 599.00, 50, 'Electronics', 'https://example.com/mouse.jpg'),
  (2, 'Notebook Set', 'Pack of 3 ruled notebooks', 199.00, 100, 'Stationery', 'https://example.com/notebooks.jpg');

-- NOTE: the password hashes above are placeholders. Run PasswordUtil.main() (see util package)
-- to generate real bcrypt hashes for admin@mymart.local / seller / buyer before using seed data
-- to actually log in, then replace these values.
